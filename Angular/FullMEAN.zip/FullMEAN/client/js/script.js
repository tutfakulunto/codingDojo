(function($) {
    'use strict';

})(jQuery);